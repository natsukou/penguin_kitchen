"""Merge multiple LeRobot v2.1 datasets into a single dataset.

This module merges multiple LeRobot dataset folders that were produced by
parallel workers into one unified dataset. It handles:
- Merging episodes, statistics, and metadata
- Reindexing episode and frame indices
- Handling dimension mismatches with padding
- Copying video files and parquet data files

Usage:
    python -m galbot_mcap2lerobot.merge_lerobot_v2_1 \
        --source_folders ds_1 ds_2 ds_3 \
        --output_folder merged_dataset
"""

import argparse
import contextlib
import json
import os
import shutil
from typing import Any

import numpy as np
import pandas as pd
from termcolor import colored
from tqdm import tqdm

# ============================================================
# JSONL I/O
# ============================================================


def load_jsonl(file_path: str) -> list[dict[str, Any]]:
    """Load data from a JSONL file.

    Handles episodes_stats.jsonl which may be formatted as a JSON array.
    """
    data = []

    if "episodes_stats.jsonl" in file_path:
        try:
            with open(file_path) as f:
                content = f.read()
                if content.strip().startswith("[") and content.strip().endswith("]"):
                    return json.loads(content)
                else:
                    try:
                        return json.loads("[" + content + "]")
                    except json.JSONDecodeError:
                        pass
        except Exception as e:
            print(f"Error loading {file_path} as JSON array: {e}")

        try:
            with open(file_path) as f:
                for line in f:
                    if line.strip():
                        with contextlib.suppress(json.JSONDecodeError):
                            data.append(json.loads(line))
        except Exception as e:
            print(f"Error loading {file_path} line by line: {e}")
    else:
        with open(file_path) as f:
            for line in f:
                if line.strip():
                    with contextlib.suppress(json.JSONDecodeError):
                        data.append(json.loads(line))

    return data


def save_jsonl(data: list[dict[str, Any]], file_path: str) -> None:
    """Save data in JSONL format (one JSON object per line)."""
    with open(file_path, "w") as f:
        for item in data:
            f.write(json.dumps(item) + "\n")


def validate_dataset_compatibility(source_folders: list[str]) -> dict[str, Any]:
    """Validate source schemas using standard LeRobot ``info.json`` metadata.

    A merge is only safe when every frame feature has the same meaning in all
    sources. In particular, equal vector lengths are insufficient if joint
    names or their order differ.

    Returns:
        The first source's ``info.json`` dictionary for use as the output
        template.

    Raises:
        RuntimeError: If required joint names are missing or source schemas
            differ.
    """
    infos: list[tuple[str, dict[str, Any]]] = []
    for folder in source_folders:
        info_path = os.path.join(folder, "meta", "info.json")
        if not os.path.isfile(info_path):
            raise RuntimeError(f"info.json not found in {folder}; refusing to merge.")
        with open(info_path) as f:
            infos.append((info_path, json.load(f)))

    reference_path, reference = infos[0]
    reference_features = reference.get("features")
    if not isinstance(reference_features, dict):
        raise RuntimeError(f"features metadata is missing from {reference_path}.")

    for feature_key in ("observation.state", "action"):
        feature = reference_features.get(feature_key)
        names = feature.get("names") if isinstance(feature, dict) else None
        shape = feature.get("shape") if isinstance(feature, dict) else None
        if not isinstance(names, list) or not names:
            raise RuntimeError(
                f"{feature_key}.names is missing from {reference_path}; "
                "regenerate the dataset with the current converter before merging."
            )
        if not isinstance(shape, list) or not shape or shape[0] != len(names):
            raise RuntimeError(
                f"{feature_key}.shape and names are inconsistent in {reference_path}: "
                f"shape={shape}, names={len(names)} entries."
            )

    layout_keys = (
        "codebase_version",
        "robot_type",
        "fps",
        "chunks_size",
        "data_path",
        "video_path",
    )
    for candidate_path, candidate in infos[1:]:
        for key in layout_keys:
            if candidate.get(key) != reference.get(key):
                raise RuntimeError(
                    f"Incompatible info.json field '{key}': {candidate_path} has "
                    f"{candidate.get(key)!r}, but {reference_path} has {reference.get(key)!r}."
                )

        candidate_features = candidate.get("features")
        if candidate_features != reference_features:
            reference_keys = set(reference_features)
            candidate_keys = set(candidate_features or {})
            if candidate_keys != reference_keys:
                raise RuntimeError(
                    f"Incompatible feature set in {candidate_path}: missing "
                    f"{sorted(reference_keys - candidate_keys)}, extra "
                    f"{sorted(candidate_keys - reference_keys)}."
                )
            for feature_key in sorted(reference_keys):
                if candidate_features[feature_key] != reference_features[feature_key]:
                    raise RuntimeError(
                        f"Incompatible feature definition for '{feature_key}' in {candidate_path}; "
                        f"it differs from {reference_path}. Check dtype, shape, names, order, "
                        "and video metadata before merging."
                    )

    return reference


def get_common_modality_metadata(source_folders: list[str]) -> str | None:
    """Return a common human-readable modality file when all sources have one.

    This metadata is optional and never defines merge compatibility; the
    official ``info.json`` schema has already been validated above.
    """
    paths = [os.path.join(folder, "meta", "modality.json") for folder in source_folders]
    existing = [path for path in paths if os.path.isfile(path)]
    if not existing:
        return None
    if len(existing) != len(paths):
        return None

    with open(existing[0]) as f:
        reference = json.load(f)
    for path in existing[1:]:
        with open(path) as f:
            if json.load(f) != reference:
                raise RuntimeError(
                    f"Readable modality metadata differs in {path}; "
                    "regenerate the source metadata before merging."
                )
    return existing[0]


def refresh_reindexed_stats(episode_stats: dict[str, Any], df: pd.DataFrame) -> None:
    """Refresh stats for columns changed by the merge reindexing pass."""
    stats = episode_stats.get("stats")
    if not isinstance(stats, dict):
        return

    for column in ("episode_index", "index", "task_index"):
        if column not in df.columns:
            continue
        values = df[column].to_numpy()
        if len(values) == 0:
            continue
        stats[column] = {
            "min": np.min(values, keepdims=True).tolist(),
            "max": np.max(values, keepdims=True).tolist(),
            "mean": np.mean(values, keepdims=True).tolist(),
            "std": np.std(values, keepdims=True).tolist(),
            "count": [len(values)],
        }


# ============================================================
# Statistics Merging
# ============================================================


def merge_stats(stats_list: list[dict[str, Any]]) -> dict[str, Any]:
    """Merge per-episode statistics from multiple datasets.

    Handles:
    - Weighted mean/std when count is available
    - Min/max aggregation
    - Dimension mismatches via padding
    - Nested image feature structures

    Args:
        stats_list: List of stats dicts, one per source dataset.

    Returns:
        Merged stats dict.
    """
    merged_stats: dict[str, Any] = {}

    common_features = set(stats_list[0].keys())
    for stats in stats_list[1:]:
        common_features &= set(stats.keys())

    for feature in stats_list[0]:
        if feature not in common_features:
            continue

        merged_stats[feature] = {}

        common_stat_types = [
            st
            for st in ["mean", "std", "max", "min"]
            if all(st in stats[feature] for stats in stats_list)
        ]

        original_shapes = []
        for stats in stats_list:
            if "mean" in stats[feature]:
                original_shapes.append(np.array(stats[feature]["mean"]).shape)

        # --- Image features: preserve nested [C, H, W] structure ---
        if feature.startswith("observation.images."):
            for stat_type in common_stat_types:
                try:
                    values = [stats[feature][stat_type] for stats in stats_list]
                    result = []
                    for ch in range(len(values[0])):
                        channel_result = []
                        for row in range(len(values[0][ch])):
                            pixel_result = []
                            for col in range(len(values[0][ch][row])):
                                if stat_type in ("mean", "std"):
                                    val = sum(v[ch][row][col] for v in values) / len(values)
                                elif stat_type == "max":
                                    val = max(v[ch][row][col] for v in values)
                                else:
                                    val = min(v[ch][row][col] for v in values)
                                pixel_result.append(val)
                            channel_result.append(pixel_result)
                        result.append(channel_result)
                    merged_stats[feature][stat_type] = result
                except Exception as e:
                    print(f"Warning: Error processing image {feature}.{stat_type}: {e}")
                    merged_stats[feature][stat_type] = values[0]

        # --- Same-shape features ---
        elif len({str(s) for s in original_shapes}) == 1:
            for stat_type in common_stat_types:
                values = [stats[feature][stat_type] for stats in stats_list]
                try:
                    if stat_type == "mean":
                        if all("count" in stats[feature] for stats in stats_list):
                            counts = [stats[feature]["count"][0] for stats in stats_list]
                            total = sum(counts)
                            weighted = [
                                np.array(v) * c / total
                                for v, c in zip(values, counts, strict=False)
                            ]
                            merged_stats[feature][stat_type] = np.sum(weighted, axis=0).tolist()
                        else:
                            merged_stats[feature][stat_type] = np.mean(values, axis=0).tolist()
                    elif stat_type == "std":
                        if all("count" in stats[feature] for stats in stats_list):
                            counts = [stats[feature]["count"][0] for stats in stats_list]
                            total = sum(counts)
                            variances = [np.array(s) ** 2 for s in values]
                            weighted = [
                                v * c / total for v, c in zip(variances, counts, strict=False)
                            ]
                            merged_stats[feature][stat_type] = np.sqrt(
                                np.sum(weighted, axis=0)
                            ).tolist()
                        else:
                            merged_stats[feature][stat_type] = np.mean(values, axis=0).tolist()
                    elif stat_type == "max":
                        merged_stats[feature][stat_type] = np.maximum.reduce(values).tolist()
                    elif stat_type == "min":
                        merged_stats[feature][stat_type] = np.minimum.reduce(values).tolist()
                except Exception as e:
                    print(f"Warning: Error processing {feature}.{stat_type}: {e}")

        # --- Different-shape state/action vectors: pad to max dim ---
        elif feature in ("observation.state", "action"):
            max_dim = max(len(np.array(stats[feature]["mean"]).flatten()) for stats in stats_list)
            for stat_type in common_stat_types:
                try:
                    pairs = [
                        (
                            np.array(stats[feature][stat_type]).flatten(),
                            len(np.array(stats[feature][stat_type]).flatten()),
                        )
                        for stats in stats_list
                    ]
                    result = np.zeros(max_dim)

                    if stat_type == "mean":
                        if all("count" in stats[feature] for stats in stats_list):
                            counts = [stats[feature]["count"][0] for stats in stats_list]
                            for d in range(max_dim):
                                vals = [
                                    (v[d], c)
                                    for (v, dim), c in zip(pairs, counts, strict=False)
                                    if d < dim
                                ]
                                if vals:
                                    result[d] = sum(v * w for v, w in vals) / sum(
                                        w for _, w in vals
                                    )
                        else:
                            for d in range(max_dim):
                                vals = [v[d] for v, dim in pairs if d < dim]
                                if vals:
                                    result[d] = sum(vals) / len(vals)
                    elif stat_type == "std":
                        if all("count" in stats[feature] for stats in stats_list):
                            counts = [stats[feature]["count"][0] for stats in stats_list]
                            for d in range(max_dim):
                                vals = [
                                    (v[d] ** 2, c)
                                    for (v, dim), c in zip(pairs, counts, strict=False)
                                    if d < dim
                                ]
                                if vals:
                                    result[d] = np.sqrt(
                                        sum(v * w for v, w in vals) / sum(w for _, w in vals)
                                    )
                        else:
                            for d in range(max_dim):
                                vals = [v[d] for v, dim in pairs if d < dim]
                                if vals:
                                    result[d] = sum(vals) / len(vals)
                    elif stat_type == "max":
                        for d in range(max_dim):
                            vals = [v[d] for v, dim in pairs if d < dim]
                            if vals:
                                result[d] = max(vals)
                    elif stat_type == "min":
                        for d in range(max_dim):
                            vals = [v[d] for v, dim in pairs if d < dim]
                            if vals:
                                result[d] = min(vals)

                    merged_stats[feature][stat_type] = result.tolist()
                except Exception as e:
                    print(f"Warning: Error processing {feature}.{stat_type}: {e}")
        else:
            for stat_type in common_stat_types:
                try:
                    merged_stats[feature][stat_type] = stats_list[0][feature][stat_type]
                except Exception as e:
                    print(f"Warning: Error processing {feature}.{stat_type}: {e}")

        if all("count" in stats[feature] for stats in stats_list):
            try:
                merged_stats[feature]["count"] = [
                    sum(stats[feature]["count"][0] for stats in stats_list)
                ]
            except Exception as e:
                print(f"Warning: Error processing {feature}.count: {e}")

    return merged_stats


# ============================================================
# Video Copying
# ============================================================


def copy_videos(
    source_folders: list[str], output_folder: str, episode_mapping: list[tuple]
) -> None:
    """Copy video files from source folders with correct episode reindexing.

    Args:
        source_folders: Source dataset folder paths.
        output_folder: Destination folder path.
        episode_mapping: List of (old_folder, old_index, new_index) tuples.
    """
    info_path = os.path.join(source_folders[0], "meta", "info.json")
    with open(info_path) as f:
        info = json.load(f)

    video_path_template = info["video_path"]
    video_keys = [name for name, feat in info["features"].items() if feat.get("dtype") == "video"]
    print(f"Found video keys: {video_keys}")

    for old_folder, old_index, new_index in episode_mapping:
        episode_chunk = old_index // info["chunks_size"]
        new_chunk = new_index // info["chunks_size"]

        for video_key in video_keys:
            source_patterns = [
                os.path.join(
                    old_folder,
                    video_path_template.format(
                        episode_chunk=episode_chunk,
                        video_key=video_key,
                        episode_index=old_index,
                    ),
                ),
            ]
            if old_index == 0:
                # Fallback for per-mcap worker temp folders, which always
                # contain exactly one episode named episode 0 regardless of
                # video_path_template/chunk math. Only valid for
                # old_index == 0 - otherwise this would silently substitute
                # episode 0's video for a different, missing episode.
                source_patterns.append(
                    os.path.join(
                        old_folder,
                        video_path_template.format(
                            episode_chunk=0, video_key=video_key, episode_index=0
                        ),
                    )
                )
                source_patterns.append(
                    os.path.join(old_folder, f"videos/chunk-000/{video_key}/episode_000000.mp4")
                )

            source_path = None
            for pattern in source_patterns:
                if os.path.exists(pattern):
                    source_path = pattern
                    break

            if source_path:
                dest_path = os.path.join(
                    output_folder,
                    video_path_template.format(
                        episode_chunk=new_chunk,
                        video_key=video_key,
                        episode_index=new_index,
                    ),
                )
                os.makedirs(os.path.dirname(dest_path), exist_ok=True)
                print(f"Copying video: {source_path} -> {dest_path}")
                shutil.copy2(source_path, dest_path)
            else:
                # Fallback: recursive search. Only safe for old_index == 0,
                # since it can't tell which episode an .mp4 it finds belongs
                # to - for any other episode it could silently substitute a
                # different episode's video.
                found = False
                if old_index == 0:
                    videos_dir = os.path.join(old_folder, "videos")
                    if os.path.isdir(videos_dir):
                        for root, _, files in os.walk(videos_dir):
                            for file in files:
                                if file.endswith(".mp4") and video_key in root:
                                    source_path = os.path.join(root, file)
                                    dest_path = os.path.join(
                                        output_folder,
                                        video_path_template.format(
                                            episode_chunk=new_chunk,
                                            video_key=video_key,
                                            episode_index=new_index,
                                        ),
                                    )
                                    os.makedirs(os.path.dirname(dest_path), exist_ok=True)
                                    shutil.copy2(source_path, dest_path)
                                    found = True
                                    break
                            if found:
                                break
                if not found:
                    # This episode's metadata (episodes.jsonl, stats, frame
                    # counts) has already been merged in as if it were
                    # complete. Continuing here would produce a dataset that
                    # claims to have this video but doesn't. Abort rather
                    # than write out incomplete data.
                    raise RuntimeError(
                        f"Video not found for {video_key}, episode {old_index} "
                        f"in {old_folder} - refusing to merge with missing video data."
                    )


# ============================================================
# Main Merge Logic
# ============================================================


def merge_datasets(source_folders: list[str], output_folder: str) -> None:
    """Merge multiple LeRobot datasets into a single dataset.

    Args:
        source_folders: List of source dataset directory paths.
        output_folder: Path for the merged output dataset.
    """
    # Filter to existing folders
    valid_folders = [f for f in source_folders if os.path.exists(f)]
    if not valid_folders:
        print("No valid source folders found.")
        return

    print(f"Merging {len(valid_folders)} datasets into {output_folder}")

    # Validate the official LeRobot schema before writing any output. This
    # prevents equal-length but differently ordered joint vectors from being
    # silently concatenated.
    info = validate_dataset_compatibility(valid_folders)
    modality_path = get_common_modality_metadata(valid_folders)

    os.makedirs(os.path.join(output_folder, "meta"), exist_ok=True)
    os.makedirs(os.path.join(output_folder, "data", "chunk-000"), exist_ok=True)

    # --- Merge episodes ---
    all_episodes = []
    all_episode_stats = []
    all_tasks = []
    episode_stats_by_index: dict[int, dict[str, Any]] = {}
    task_registry: dict[str, int] = {}  # task text -> merged task_index
    folder_task_maps: dict[str, dict[int, int]] = {}  # folder -> {old_task_index: new_task_index}
    episode_mapping = []  # (old_folder, old_index, new_index)
    current_episode = 0
    current_frame = 0

    for folder in tqdm(valid_folders, desc="Merging datasets"):
        episodes_path = os.path.join(folder, "meta", "episodes.jsonl")
        stats_path = os.path.join(folder, "meta", "episodes_stats.jsonl")
        tasks_path = os.path.join(folder, "meta", "tasks.jsonl")

        if not os.path.exists(episodes_path):
            print(f"Skipping {folder}: no episodes.jsonl")
            continue

        episodes = load_jsonl(episodes_path)
        ep_stats = load_jsonl(stats_path) if os.path.exists(stats_path) else []
        tasks = load_jsonl(tasks_path) if os.path.exists(tasks_path) else []

        # Map this folder's task_index values onto a global registry keyed by
        # task text, so identical tasks share one index and folders that reuse
        # the same index for different tasks don't collide.
        folder_task_map: dict[int, int] = {}
        for task in tasks:
            text = task.get("task")
            old_task_index = task.get("task_index")
            if text not in task_registry:
                task_registry[text] = len(task_registry)
                all_tasks.append({"task_index": task_registry[text], "task": text})
            folder_task_map[old_task_index] = task_registry[text]
        folder_task_maps[folder] = folder_task_map

        # Track this folder's old->new episode_index mapping so per-episode
        # stats (keyed by the folder-local episode_index) can be remapped too.
        folder_episode_map: dict[int, int] = {}

        for ep in episodes:
            old_index = ep.get("episode_index", 0)
            new_index = current_episode

            # Update episode metadata
            ep_length = ep.get("length", 0)
            new_ep = dict(ep)
            new_ep["episode_index"] = new_index
            all_episodes.append(new_ep)

            episode_mapping.append((folder, old_index, new_index))
            folder_episode_map[old_index] = new_index
            current_episode += 1
            current_frame += ep_length

        for stat in ep_stats:
            old_stat_index = stat.get("episode_index")
            if old_stat_index not in folder_episode_map:
                print(
                    f"Warning: episodes_stats.jsonl entry {old_stat_index} in {folder} "
                    "has no matching episode, skipping"
                )
                continue
            new_stat = dict(stat)
            new_stat["episode_index"] = folder_episode_map[old_stat_index]
            all_episode_stats.append(new_stat)
            episode_stats_by_index[new_stat["episode_index"]] = new_stat

    # --- Copy and reindex parquet files ---
    # episode_mapping is in the same order new_index was assigned (0, 1, 2, ...),
    # so accumulating frame_offset in this order yields a globally contiguous
    # 'index' column, matching what a single-worker conversion would produce.
    frame_offset = 0
    for old_folder, old_index, new_index in tqdm(episode_mapping, desc="Copying parquet"):
        old_chunk = old_index // info["chunks_size"]
        new_chunk = new_index // info["chunks_size"]

        data_path_template = info.get(
            "data_path",
            "data/chunk-{episode_chunk:03d}/episode_{episode_index:06d}.parquet",
        )

        source_patterns = [
            os.path.join(
                old_folder,
                data_path_template.format(episode_chunk=old_chunk, episode_index=old_index),
            ),
        ]
        if old_index == 0:
            # Fallback for per-mcap worker temp folders, which always contain
            # exactly one episode named episode_000000.parquet regardless of
            # data_path_template/chunk math. Only valid for old_index == 0 -
            # otherwise this would silently substitute episode 0's data for a
            # different, missing episode.
            source_patterns.append(
                os.path.join(old_folder, "data/chunk-000/episode_000000.parquet")
            )

        source_path = None
        for pattern in source_patterns:
            if os.path.exists(pattern):
                source_path = pattern
                break

        if source_path is None:
            # This episode's metadata (episodes.jsonl, stats, frame counts)
            # was already merged in earlier as if it were complete. Silently
            # skipping here would leave a "ghost" episode in the output:
            # present in metadata but with no parquet file on disk. Abort
            # rather than write out an inconsistent dataset.
            raise RuntimeError(
                f"Parquet file not found for episode {old_index} in {old_folder} "
                "- refusing to merge with missing frame data."
            )

        dest_path = os.path.join(
            output_folder,
            data_path_template.format(episode_chunk=new_chunk, episode_index=new_index),
        )
        os.makedirs(os.path.dirname(dest_path), exist_ok=True)

        df = pd.read_parquet(source_path)
        df["episode_index"] = new_index
        if "task_index" in df.columns:
            folder_task_map = folder_task_maps.get(old_folder, {})
            mapped = df["task_index"].map(folder_task_map)
            if mapped.isna().any():
                # Some rows' task_index has no entry in this folder's
                # tasks.jsonl (e.g. missing/empty tasks.jsonl). map()
                # silently turns those into NaN, which would silently
                # corrupt this int column and mislabel frames at training
                # time. Abort rather than write out bad data.
                unmapped = sorted(df.loc[mapped.isna(), "task_index"].unique().tolist())
                raise RuntimeError(
                    f"task_index {unmapped} in {old_folder} (episode {old_index}) "
                    "has no entry in tasks.jsonl - refusing to merge with "
                    "unresolvable task labels. Check tasks.jsonl for this folder."
                )
            df["task_index"] = mapped.astype(df["task_index"].dtype)
        if "index" in df.columns:
            df["index"] = np.arange(frame_offset, frame_offset + len(df))
        frame_offset += len(df)
        if new_index in episode_stats_by_index:
            refresh_reindexed_stats(episode_stats_by_index[new_index], df)
        df.to_parquet(dest_path, index=False)

    # --- Copy videos ---
    copy_videos(valid_folders, output_folder, episode_mapping)

    # --- Save per-episode statistics ---
    if all_episode_stats:
        save_jsonl(
            all_episode_stats,
            os.path.join(output_folder, "meta", "episodes_stats.jsonl"),
        )

    # --- Save metadata ---
    save_jsonl(all_episodes, os.path.join(output_folder, "meta", "episodes.jsonl"))
    save_jsonl(all_tasks, os.path.join(output_folder, "meta", "tasks.jsonl"))
    if modality_path is not None:
        shutil.copy2(modality_path, os.path.join(output_folder, "meta", "modality.json"))
    # Update info.json totals, which the template (copied from the first
    # source folder) otherwise leaves stale for anything beyond that folder's
    # own single-conversion episode count.
    video_keys = [name for name, feat in info["features"].items() if feat.get("dtype") == "video"]
    info["total_episodes"] = current_episode
    info["total_frames"] = current_frame
    info["total_tasks"] = len(all_tasks)
    info["total_videos"] = current_episode * len(video_keys)
    chunks_size = info["chunks_size"]
    info["total_chunks"] = (current_episode - 1) // chunks_size + 1 if current_episode else 0
    info["splits"] = {"train": f"0:{current_episode}"}
    with open(os.path.join(output_folder, "meta", "info.json"), "w") as f:
        json.dump(info, f, indent=2)

    print(
        colored(
            f"Merge complete: {current_episode} episodes, {current_frame} frames",
            "green",
        )
    )


# ============================================================
# CLI Entry Point
# ============================================================


def main() -> None:
    parser = argparse.ArgumentParser(description="Merge LeRobot v2.1 datasets")
    parser.add_argument(
        "--source_folders",
        nargs="+",
        required=True,
        help="Paths to source dataset folders",
    )
    parser.add_argument(
        "--output_folder", required=True, help="Path to output merged dataset folder"
    )
    args = parser.parse_args()
    merge_datasets(args.source_folders, args.output_folder)


if __name__ == "__main__":
    main()
